#coding=utf-8
import sys
sys.path.append('../tools/')
from DateUtil import DateUtil
from singleton import RedisResources

#test
if __name__=='__main__':
    if 0:
        pass
    else:
        print u'你阿红'
