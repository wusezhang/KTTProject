#!/usr/bin/python
#coding=utf-8
import sys
sys.path.append('../tools/')

import httplib
import redis
import random
import traceback
import re

from DateUtil import DateUtil
from singleton import RedisResources
from singleton import Log
###
#  edit by
#    rowland  de  man
#
###
class AssembleHandler:
    '''
        Attributes                  Comment
            host                       /
            keylife                    key/value alive time in redis (unit:second)
    '''
    
    def __init__(self):
        self.keylife = 60*60*24
        self.log = Log(repr(self))
        self.logger = self.log.getLog()
    def process(self,path,interval=60):
        '''
        1.Check the content in redis if it has expired
        2.Yes it did expire then goto step.3/ No,it hasn't then return the value which in redis
        3.Get to the remote URL to fetch the content via HTTP protocol,then return it and write to the redis
        ps. in order to avoid a large number of requests come in the same time,interval will be a little randomized adjusted.
        '''
        path.replace("http://","")
        interval = interval-random.randint(0,interval/20)
        #begins time
        bt = DateUtil.curtime()
        r = RedisResources().getConn()
        content = None
        redisError = False
        host = path[:path.index("/")]
        tail = path[path.index("/"):]
        try:
            content = r.get(path)
            #raise Exception('a')
        except Exception,e:
            self.logger.exception('exception')
            redisError = True
        timestamp = ''
        # key exists!
        if content:
            content = eval(content)
            timestamp = content.get('timestamp')
            when = content.get('when')
            gasp = None
            freashFlag = False
            if when:
                if DateUtil.curtime()<when:
                    freashFlag = True
            else:
                if DateUtil.since(timestamp)<interval:
                    freashFlag = True
            if freashFlag:
                # remain freash
                # cost time
                cost = repr(round(DateUtil.curtime()-bt,4))
                self.logger.info('cache hit! key=[' + path + '] timestamp=[' + timestamp + '] interval=[' + repr(interval) + '] costs:' + cost + 's')
                self.logger.removeHandler(self.log.fh)
                return content.get('xml')
            else:
                # expired
                
                con = httplib.HTTPConnection(host,timeout=5)
                requestheader = eval("{'If-Modified-Since': '" + timestamp + "'}")
                res=None
                try:
                    con.request('GET' , tail , headers=requestheader)
                    res = con.getresponse()
                    if res.status == 304:
                        # return redis snapshot
                        # cost time
                        cost = repr(round(DateUtil.curtime()-bt,4))
                        self.logger.info('cache remain(304)! key=[' + path + '] timestamp=[' + timestamp + '] interval=[' + repr(interval) + '] costs:' + cost + 's')
                        # will hold a little longer
                        addsec = interval/3
                        if addsec<5:
                            addsec = 5
                        #refresh attribute 'when'
                        content['when'] = DateUtil.curtime() + addsec;
                        rv = repr(content)
                        r.set(path,rv,self.keylife)
                        self.logger.removeHandler(self.log.fh)
                        return content.get('xml')
                    elif res.status == 200:
                        #will update redis snapshot ,return the new snapshot  
                        #last modify time
                        lmt = res.getheader('last-modified')
                        #xml content itself
                        xci = res.read()
                        #pick time
                        pt = DateUtil.curtime() + interval;
                        #component 
                        comp = {}
                        comp['timestamp'] = lmt
                        comp['xml'] = xci
                        comp['when'] = pt
                        #redis value(string)
                        rv = repr(comp)
                        r.set(path,rv,self.keylife)
                        # cost time
                        cost = repr(round(DateUtil.curtime()-bt,4))
                        self.logger.info('cache renew(200)! key=[' + path + '] timestamp=[' + lmt + '] costs:' + cost + 's')
                        self.logger.removeHandler(self.log.fh)
                        return xci
                except Exception,e:
                    self.logger.exception('exception')
                    self.logger.removeHandler(self.log.fh)
                    raise e
                finally :
                    if res:
                        res.close()
                    if con:
                        con.close()
        else:
        #key dosen't exists!
        #fetch it from remote server directly (without ask modify time)
            con = httplib.HTTPConnection(host,timeout=5)
            con.request('GET' , tail , headers={})
            res = None
            try:
                res = con.getresponse()
                if res.status <> 200:
                    raise Exception("http status:"+res.status)
                lmt = res.getheader('last-modified')
                xci = res.read()
                pt = DateUtil.curtime() + interval
                if not redisError:
                    comp = {}
                    comp['timestamp'] = lmt
                    comp['xml'] = xci
                    comp['when'] = pt
                    rv = repr(comp)
                    r.set(path,rv,self.keylife)
                    cost = repr(round(DateUtil.curtime()-bt,4))
                    self.logger.info('cache miss! key=[' + path + '] timestamp=[' + timestamp + '] interval=[' + repr(interval) + '] costs:' + cost + 's')
                    self.logger.removeHandler(self.log.fh)
                return xci
            except Exception,e:
                    self.logger.exception('exception')
                    self.logger.removeHandler(self.log.fh)
                    raise e
            finally :
                if res:
                    res.close()
                if con:
                    con.close()
        

#test
if __name__ == '__main__':
    test = AssembleHandler()
    #test.process('static/public/xysc/xml/historyopen.xml',600)
    print test.process('www.500.com/static/info/kaijiang/xml/dlt/list50.xml',600)
    #print DateUtil.since("Fri, 27 Dec 2013 07:20:04 GMT")
