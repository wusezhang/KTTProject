#!/usr/bin/python
#coding=utf-8
import sys
import tornado.ioloop
import tornado.web
import re
#app path build-ups
sys.path.append('handler/')
sys.path.append('tools/')
sys.path.append('templates/')
from assemble import AssembleHandler
from singleton import Log

class MainHandler(tornado.web.RequestHandler):
    log = Log("main_handler")
    logger = log.getLog()
    def get(self,path):
        if path == "snapshot":
            #path = self.get_argument("path")
            #interval = self.get_argument("interval")
            #self.write(self.handle(path,interval))
            paras = (self.request.arguments)
            path = paras.get('path')
            if path:
                path = path[0]
            interval = paras.get('interval')
            if interval and re.match(r"^\d+$",interval[0]):
                interval = interval[0]
            else:
                interval = None
            resp = ""
            try:
                resp = self.handle(path,interval)
            except Exception,e:
                logger.exception('exception')
                logger.removeHandler(log.fh) 
                sys.exit(2)
            self.write(resp)
        else:
            raise tornado.web.HTTPError(404)
    def post(self,path):
        self.get(path)
    def handle(self,path,interval):
        ah = AssembleHandler()
        try:
            ret = None
            if not path:
                return "<p>no path found!</p>"
            if not interval:
                ret = ah.process(path)
            else:
                ret = ah.process(path,int(interval))
            return ret
        except Exception,e:
            raise e
            
application = tornado.web.Application([
    (r"/([^/]*)", MainHandler),
])

if __name__ == "__main__":
    log = Log('__main__')
    logger = log.getLog() 
    try:
        port=8888
        if len(sys.argv)>1:
            port = int(sys.argv[1])
        application.listen(port)
        tornado.ioloop.IOLoop.instance().start()
    except:
        logger.exception('exception')
        logger.removeHandler(log.fh)
        sys.exit(2)




