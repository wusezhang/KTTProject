#coding=utf-8
import redis
import logging
import os
from DateUtil import DateUtil

class Singleton(object):
    '''This is a singleton class, you can put heavy weight resources in its extensions'''
    def __new__(cls,*args,**kw):
        if not hasattr(cls,'_instance'):
            orig = super(Singleton,cls)
            #cls._instance = orig.__new__(cls,*args,**kw)
            cls._instance = orig.__new__(cls)
        return cls._instance

class RedisResources(Singleton):
    '''redis decorator'''
    def __init__(self):
        #online
        #self.redisUrl='192.168.10.129'
        #offline
        #self.redisUrl = '192.168.41.141'
        self.redisUrl = 'localhost'
        self.rc=redis.Redis(self.redisUrl,socket_timeout=3)
        #self.POOL = redis.ConnectionPool(host=self.redisUrl, port=6379, db=0,socket_timeout=3)
    def getConn(self):
        '''return a available redis client '''
        try:
            if not self.rc.client_getname():
                self.rc=redis.Redis(self.redisUrl,socket_timeout=3)
        except Exception,e:
            raise e
        return self.rc

class Log(Singleton):
    '''logging stuff'''
    def __init__(self,where):
        #offline
        self.filepath = os.getcwd() + '/log/'
        #online
        #self.filepath = '/var/log/500wan/xmlcache/log/'
        self.logfile = DateUtil.when() + ".log"
        #in case folder not exists
        if not os.path.exists(self.filepath):
            os.makedirs(self.filepath)
        #in case file not exists
        if not os.path.exists(self.filepath+self.logfile):
            f=open(self.filepath+self.logfile,'a')
            f.close()
        self.logger=logging.getLogger(where)
        self.logger.setLevel(logging.INFO)
        self.fh = logging.FileHandler(self.filepath+self.logfile)
        self.fmt = logging.Formatter('%(asctime)s-[%(process)d]-[%(name)s]-[%(levelname)s] %(message)s')
        self.fh.setFormatter(self.fmt)
        self.logger.addHandler(self.fh)
    def getLog(self):
        return self.logger
        
#test        
if __name__=='__main__':
    for x in range(0,10):
        one = RedisResources().getConn()
        print one.get('static/public/xysc/xml/historyopen.xml')
  
