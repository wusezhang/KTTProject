#!/usr/bin/python
#coding=utf-8
import time

class DateUtil:
    @staticmethod
    def since(dateStr):
    ###
    #1.Tranffer the date string pass in into GMT datetime A.
    #2.Get 'now' time B.
    #3.Return A minus B (seconds)
    ###
        gmt_format = '%a, %d %b %Y %H:%M:%S GMT'
        if not dateStr:
            raise Exception("Compare to What?")
        return time.mktime(time.gmtime())-time.mktime(time.strptime(dateStr,gmt_format))
    @staticmethod
    def when(fmt='%Y-%m-%d'):
        return time.strftime(fmt)
    @staticmethod
    def curtime():
        return time.time()
    @staticmethod
    def gmtadd(gmtdateStr,sec):
        gmt_format = '%a, %d %b %Y %H:%M:%S GMT'
        secs = time.mktime(time.strptime(gmtdateStr,gmt_format))
        secs = secs + sec
        return time.strftime(gmt_format,time.localtime(secs))
#test
if __name__=='__main__':
    #print DateUtil.getsecsfromnow('Thu, 26 Dec 2013 08:10:57 GMT')
    print DateUtil.gmtadd( 'Thu, 26 Dec 2013 08:10:57 GMT',20)
